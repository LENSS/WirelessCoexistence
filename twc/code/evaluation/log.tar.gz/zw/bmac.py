#!/usr/bin/env python
import re
import sys

trans=re.compile('transmitted_frame_count')
retry=re.compile('retry_count')

for i in range(1,63):
  fn='bmac/'+str(i)+'.txt'
  print fn
  #f=open(sys.argv[1], 'r')
  f=open(fn, 'r')
  w=open('bmac.txt', 'a')
  ls=[]
  flag=0
  count=0
  delimiter=0
  #print sys.argv[1]
  print fn
  w.write('================\n')
  #w.write(sys.argv[1]+'\n\n')
  w.write(fn+'\n\n')
  
  for line in f:
    line = line.strip()
    r=trans.search(line)
    if r!=None:
      count=count+1
      #print line
  count=count/4
  
  f.close()
  f=open(fn, 'r')
  #f=open(sys.argv[1], 'r')
  
  for line in f:
    line = line.strip()
    if flag==1:
      #print line
      #if count!=0 and count%2!=0:
      #  ls.append(line)
      flag=0
      print line
      w.write(line+'\n')
      #if count!=0 and count%2==0:
      #  ls.append(' '+line)
      #  s=''.join(ls[count-2:count])
      #  print s
      #  w.write(s+'\n')
      delimiter=delimiter+1
      if delimiter==count:
        delimiter=0
        print ""
        w.write('\n')
    r=trans.search(line)
    if r!=None:
      flag=1
      #count=count+1
      #print line
  #
  #  r=retry.search(line)
  #  if r!=None:
  #    flag=1
  #    #print line
  flag=0
  delimiter=0
  #
  ls[:]=[]
  print ''
  w.write('\n')
  f.close()
  f=open(fn, 'r')
  #f=open(sys.argv[1], 'r')
  for line in f:
    line = line.strip()
    if flag==1:
      #print line
      #if count!=0 and count%2!=0:
      #  ls.append(line)
      flag=0
      print line
      w.write(line+'\n')
      #if count!=0 and count%2==0:
      #  ls.append(' '+line)
      #  s=''.join(ls[count-2:count])
      #  print s
      #  w.write(s+'\n')
      delimiter=delimiter+1
      if delimiter==count:
        delimiter=0
        print ''
        w.write('\n')
    r=retry.search(line)
    if r!=None:
      flag=1
      #count=count+1
  
  
  
  w.close()
  f.close()


