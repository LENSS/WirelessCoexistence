#!/usr/bin/env python
import os
import sys

f=open(sys.argv[1], 'r')
count=0


for line in f:
  line = line.strip()
  if count%8==0: 
    #line='Bmac.log.zw-desktop.2012.07.03.10.48.11'
    cmd='cat '+line+'* >'+ str(count/8+1) +'.txt'
    print cmd
    os.system(cmd)
  count=count+1
f.close()
